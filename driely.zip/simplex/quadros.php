<?php
require_once('view/template.php');
require_once('simplex.php');
$simplex = new Simplex;
$tela = new template;
$tela->SetTitle('SIMPLEX');
$tela->SetProjectName('SIMPLEX');
session_start();
$etapa = 0;
$tabela = array();
$linhaZ = array();
$conteudo='';
$qtderepeticoes=1;
$qtdecolunas = $_SESSION['qtdevariaveis']+$_SESSION['qtderestricoes']+2;	
$qtdelinhas = $_SESSION['qtderestricoes'] + 2;
$linhadopivo=$posicaosai;
$solucao = 0;
//0 - otima
//1 - indeterminada
//2 - impossivel




$tabela[0][0]="Base";
	for ($coluna=1; $coluna <= $_SESSION['qtdevariaveis'] ; $coluna++) { 
		$tabela[0][$coluna]='X<sub>'.$coluna.'</sub>';
	}
	for ($coluna=$_SESSION['qtdevariaveis']+1; $coluna <= $_SESSION['qtderestricoes']+$_SESSION['qtdevariaveis'] ; $coluna++) { 
		$tabela[0][$coluna]='F<sub>'.($coluna-$_SESSION['qtdevariaveis']).'</sub>';
	}
	$tabela[0][$coluna]='B';

	    //for ($linha=1; $linha < $qtdelinhas; $linha++) { 
    for ($linha=1; $linha <= $_SESSION['qtderestricoes']; $linha++) { 
		$tabela[$linha][0]='F<sub>'.$linha.'</sub>';
		for ($coluna=1; $coluna <= $_SESSION['qtdevariaveis']; $coluna++) { 
			$tabela[$linha][$coluna]=$_SESSION['r'.$linha.'_'.$coluna];
		}
		for ($coluna=$_SESSION['qtdevariaveis']+1; $coluna <=  $_SESSION['qtderestricoes']+$_SESSION['qtdevariaveis'] ; $coluna++) { 
			if($linha!=$coluna-$_SESSION['qtdevariaveis']){
				$tabela[$linha][$coluna]='0';
			}else{
				$tabela[$linha][$coluna]='1';
			}
		}
		$tabela[$linha][$coluna]=$_SESSION['resultado'.$linha];
	}
	$tabela[$_SESSION['qtderestricoes']+1][0]='Z';
	for ($coluna=1; $coluna <= $_SESSION['qtdevariaveis'] ; $coluna++) {
		if ($_SESSION['objetivo2']=='+'){ 
		    $tabela[$_SESSION['qtderestricoes']+1][$coluna]=($_SESSION['z'.$coluna])*-1;
	    }else{
			$tabela[$_SESSION['qtderestricoes']+1][$coluna]=$_SESSION['z'.$coluna];
		}
	}
	for ($coluna=$_SESSION['qtdevariaveis']+1; $coluna <= $_SESSION['qtderestricoes']+$_SESSION['qtdevariaveis']+1; $coluna++) { 
		 $tabela[$_SESSION['qtderestricoes']+1][$coluna]=0;
	}



do{		
    





	//descobre quem entra e sai da base
	$etapa++;
	$conteudo=$conteudo.'<br><h3>Etapa : '.$etapa.'</h3><h5>Descobrindo quem entra e quem sai da base.</h5>';
	$simplex->SetTabela($tabela);
	$conteudo=$conteudo.$simplex->MostraTabela('12',$qtdecolunas,$qtdelinhas);
    
    //pega o menor numero 
    $menor=0;
    $ColunaDoMenor=0;
    for ($coluna=1; $coluna < $qtdecolunas ; $coluna++) { 
		if (($tabela[$qtdelinhas-1][$coluna]<$menor) and ($tabela[$qtdelinhas-1][$coluna]<0)){
			$menor=$tabela[$qtdelinhas-1][$coluna];
			$ColunaDoMenor=$coluna;
		}		
	}

    //pega quem sai
    $divisao;
    $menor=9999999999;
    $LinhaDoMenor=0;
    $contas=array();
	for ($linha=1; $linha <$qtdelinhas-1; $linha++) { 
		if(($tabela[$linha][$qtdecolunas-1]!=0) and ($tabela[$linha][$ColunaDoMenor]!=0)){
			$divisao=$tabela[$linha][$qtdecolunas-1]/$tabela[$linha][$ColunaDoMenor];
			array_push($contas,$tabela[$linha][$qtdecolunas-1].'/'.$tabela[$linha][$ColunaDoMenor].'='.$tabela[$linha][$qtdecolunas-1]/$tabela[$linha][$ColunaDoMenor]);
			if($divisao<$menor){
				$menor=$divisao;
				$LinhaDoMenor=$linha;
			}
		}
	}

	$pivo = $tabela[$LinhaDoMenor][$ColunaDoMenor];
	$naobasicas = array();


	

	$conteudo=$conteudo.'<h5><strong>Quem entra na base :</strong>'.$tabela[0][$ColunaDoMenor];
	$conteudo=$conteudo.'<h5><strong>Quem Sai da base :</strong>'.$tabela[$LinhaDoMenor][0];
	array_push($naobasicas, $tabela[$LinhaDoMenor][0]);
	$conteudo=$conteudo.'<h5><strong>Calculos:</strong><br>';
	for ($i=0; $i < count($contas); $i++) { 
		$conteudo=$conteudo.'<h5>'.$contas[$i].'<br>';
	}
	//$conteudo=$conteudo.'<h5><strong>'..'</strong><br>';
	$conteudo=$conteudo.'<h5><strong>Consequentemente sabe-se que o pivo é '.$pivo.';</strong></h5>';
	
	//entra e sai da base
	$tabela[$LinhaDoMenor][0] = $tabela[0][$ColunaDoMenor];  


///////////////////////////////////////////////////



	$etapa++;
	$conteudo=$conteudo.'<br><h3>Etapa : '.$etapa.'</h3><h5>Dividindo a linha do pivo.</h5>';
	$simplex->SetTabela($tabela);
	$conteudo=$conteudo.$simplex->MostraTabela('12',$qtdecolunas,$qtdelinhas);

	if ($pivo<=0){
		$solucao=2;//impossivel
		break;
	}

	$ValoresLinha = array();
	for ($coluna=1; $coluna < $qtdecolunas; $coluna++) { 
		$tabela[$LinhaDoMenor][$coluna]= $tabela[$LinhaDoMenor][$coluna].'/'.$pivo;
		array_push($ValoresLinha,$tabela[$LinhaDoMenor][$coluna]/$pivo);
	}

    $etapa++;
	$conteudo=$conteudo.'<br><h3>Etapa : '.$etapa.'</h3><h5>Divide-se a linha inteira do pivo pelo seu valor.</h5>';
	$conteudo=$conteudo.
						'
						<div style="text-align:center;">
							<img src="img/seta" style="width:150px;">
						</div>';
	
	$simplex->SetTabela($tabela);
	$conteudo=$conteudo.$simplex->MostraTabela('6',$qtdecolunas,$qtdelinhas);

	for ($coluna=1; $coluna < $qtdecolunas; $coluna++) { 
		$tabela[$LinhaDoMenor][$coluna]= round($ValoresLinha[$coluna-1],1);
	}

	$simplex->SetTabela($tabela);
	$conteudo=$conteudo.$simplex->MostraTabela('6',$qtdecolunas,$qtdelinhas);

	$conteudo=$conteudo.'<h5><strong>A linha do pivo foi toda dividida por pivo</strong><br>';

///////////////////////////anular//////////



				$etapa++;
				$conteudo=$conteudo.'<br><h3>Etapa : '.$etapa.'</h3><h5>Tornar nulo os outros elementos da coluna </h5>';

				$simplex->SetTabela($tabela);
				$conteudo=$conteudo.
				'
				<div style="text-align:center;">
					<img src="img/seta" style="width:150px;">
				</div>';
				$conteudo=$conteudo.$simplex->MostraTabela('6',$qtdecolunas,$qtdelinhas);


				//anular
				//$anulados= array();
				$aux = 0;
				for ($linha=1; $linha < $qtdelinhas ; $linha++) { 						
						if (($tabela[$linha][$ColunaDoMenor]!=0) and ($linha!=$LinhaDoMenor)){
							$anulados[$aux]=$tabela[$linha][$ColunaDoMenor];
							$aux++; 
							$ValorQueVaiSerAnulado = ($tabela[$linha][$ColunaDoMenor])*-1;
							for ($coluna=1; $coluna < $qtdecolunas; $coluna++) { 
								$ValorLinhaDeCima = $tabela[$LinhaDoMenor][$coluna];							
								$ValorLinhaDeBaixo = $tabela[$linha][$coluna];
								$tabela[$linha][$coluna]=($ValorLinhaDeCima*$ValorQueVaiSerAnulado+$ValorLinhaDeBaixo);	
								}
						}
				}


//mostra tabela com valores anulados
				$simplex->SetTabela($tabela);
				$conteudo=$conteudo.$simplex->MostraTabela('6',$qtdecolunas,$qtdelinhas);

				$conteudo=$conteudo.'<h5><strong>Foram anulados da colunas do pivo os numeros ( ';
		    
		        for ($i=0; $i < count($anulados); $i++) { 
		        	$conteudo=$conteudo.$anulados[$i];
		        	if ($i<count($anulados)-1){
		        		$conteudo=$conteudo.'   ;   ';
		        	}
		        }
		        $conteudo=$conteudo.' )  Ignorando o próprio pivo e os zeros. </h5></strong>';









	$negativos=0;
	for ($coluna=1; $coluna < $qtdecolunas ; $coluna++) { 
		if ($tabela[$qtdelinhas-1][$coluna]<0){
			$negativos++;
		}
	}
	if ($negativos==0){
		$solucao=0;
		break;
	}else{
		if ($qtderepeticoes==10){
			$solucao=1;
			break;
	   	}
	}
	$qtderepeticoes++;
}while($qtderepeticoes<=10);



$basicas= array();
////MOSTRA O RESULTADO
switch ($solucao) {
	case 0 :			
		$conteudo=$conteudo.
							'
							<div class="container">
							 <div class="row">
										<div class="alert alert-success" role="alert">
								        	<strong>Solução Ótima</strong>
								        </div>
   							     	 </div>
							    <div class="jumbotron">
							        <h4>Variáveis Basicas</h1>';
        for ($linha=1; $linha < $qtdelinhas ; $linha++) { 
        	if ((substr(strtoupper(trim($tabela[$linha][0])),0,1)=='F')){
      		     $conteudo=$conteudo.'<p>'.$tabela[$linha][0].' = '.$tabela[$linha][$qtdecolunas-1].'  ---->     indica sobra/falta (se resultado negativo) de '.$tabela[$linha][$qtdecolunas-1].' unidades do recurso R'.$linha.' e a ultilização de '.$tabela[$linha][$qtdecolunas-1].' unidades.</p>';
        	}else{
        		if((substr(strtoupper(trim($tabela[$linha][0])),0,1)!='Z')){
        		 	$conteudo=$conteudo.'<p>'.$tabela[$linha][0].' = '.$tabela[$linha][$qtdecolunas-1].'  ---->     indica produção de '.$tabela[$linha][$qtdecolunas-1].' unidades do produto  P'.$linha.'.</p>';
          		}else{
          			$conteudo=$conteudo.'<p>'.$tabela[$linha][0].' = '.$tabela[$linha][$qtdecolunas-1].'<br>';
          		}
          	}
        }
	    $conteudo=$conteudo.'<h4>Variáveis não Basicas</h1>';
	  
	    
	    $basicas=null;
	    $aux=0;
	    for ($i=1; $i < $qtdelinhas ; $i++) { 
     		$basicas[$aux]=$tabela[$i][0];
			$aux++;
     	}



     	for ($i=1; $i < $qtdecolunas; $i++) { 
     		$contador=0;
     		$Variavel;
     		for ($y=1; $y < $qtdelinhas ; $y++) { 
     			if($tabela[0][$i]==$tabela[$y][0]){
     				$contador++;
     			}     			
     		}
     		if($contador==0){
     				$conteudo=$conteudo.'<p>'.$tabela[0][$i].' = 0     ->    indica sobra/falta de 0 unidades do recurso R'.substr($tabela[0][$i],6,1).' que significa a utilização total dos recursos.</p><br>';
     	    }
     	}

		$conteudo=$conteudo.'</script></div></div><script>alert("Solução Ótima !!!!!");</script>';

		$_SESSION['tabela']=$tabela;
		break;
	case 1 :
		 $conteudo=$conteudo.'<div class="container">
							 	<div class="row">
										<div class="alert alert-info" role="alert">
								        	<strong>Solução indeterminada !!!!!!</strong>
								        	<strong>O limite de 10 repetições se excedeu sem nenhum resultado</strong>
								        </div>
   								</div>
   							 </div><script>alert("Solução indeterminada !!!!!");</script>';
   	break;
	default:
		$conteudo=$conteudo.'<div class="container">
							 	<div class="row">
										<div class="alert alert-danger" role="alert">
								        	<strong>Solução impossivel !!!!!!!!!</strong>
								        	<strong>Pivo encontrado é igual a zero</strong>
								        </div>
   								</div>
   							 </div><script>alert("Solução impossivel !!!!!");</script>';
	break;
}


 

$tela->SetContent($conteudo);
$tela->ShowTemplate();
?>