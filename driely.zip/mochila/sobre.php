<html>
<head>
  <meta charset="utf-8">
  <title>Algoritmo da Mochila</title>
  <link rel="stylesheet" href="estilosimplex.css">
  <script type="text/javascript" src="scripts.js"></script>
  <script type="text/javascript" src="../jquery.min.js"></script>
  <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
</head>
<body style="background-color:#d9edf7;">
	<div style="text-align:center;">
    	<h1 style="color:#31708f;">Algoritmo da Mochila</h1>
      		
      		<div>
                <h3><span>Versão 0.1</span></h3>
            <span>-Implementação de definição de capacidade da mochila</span><br>
      			<span>-Implementação de rotina de inclusão de itens na tabela</span><br>
            <span>-Validação de campos via javascript</span><br>
                <h3><span>Versão 0.2</span></h3>
            <span>-Rotina (VerificaItens) para inclusão dos itens na mochila</span><br>
            <span>-Separação das telas de inclusão de itens e resultado</span><br>

    		<strong><h3>Desenvolvido por:</h3>
     	 		<span>Driely Aoyama - 521779</span><br>
     	 		<span>Gustavo Menezes - 515655</span><br>
     	 		<span>Alecsander Porto - 513814</span>
                </div></strong>

  	</div>
</body>
</html>