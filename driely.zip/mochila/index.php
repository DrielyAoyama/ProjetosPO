<?php require('/elements/header.php' ); ?>
<div class="container">
    <div class="center">
    <h1>Mochila</h1>
    <hr>
      <div class="settings">
        <form action="processa1.php" name="formulario" method="GET" onsubmit="return validar()">
            <label for="capacidade">Capacidade da Mochila</label>  
            <input id="capacidade" name="capacidade" type="number" placeholder="" class="form-control input-md" required="">
            <br>
            <button id="btnAddItem" type="submit" class="btn btn-primary btn-block";>
              <span class="glyphicon glyphicon-briefcase"></span>
            </button>
        </form>
      </div><!-- <div class="settings">-->
    </div><!--div class="center"-->
</div><!--<div class="container">-->

<script type="text/javascript">
function validar(){
  if((document.formulario.capacidade.value=="")||(document.formulario.capacidade.value<=0)) {
    alert( "Preencha o campo corretamente!" );
    return false; 
    } 
}
</script>

<?php 
$_SESSION['qtdelinhas'] = 1;
$_SESSION['qtdeitens'] = 1;




require('/elements/footer.php' ); ?>