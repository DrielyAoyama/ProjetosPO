<?php 
$tabela = array();
require('/elements/header.php' );
require('/functions/functions.php');
?>
<br>
<br>
<div class="container">	
	<form name="formulario" action="processa2.php" method="GET" onSubmit="return validar(<?php echo $_SESSION['capacidade']?>);">
		<div class="col-md-3">
		    <div class="form-group">
		        <label>Peso do item</label>
		        <input type="number"  class="form-control" name="peso" value="0" required="" />
		    </div>
		</div>
		<div class="col-md-3">
		    <div class="form-group">
		        <label>Valor do item</label>
		        <input type="number" class="form-control" name="valor" value="0" required=""/>
		    </div>
		</div>
		<div class="col-md-3">
		    <div class="form-group">
		        <label>Adicionar item</label>
		        <button id="btnAddItem" type=buttom  class="btn btn-primary btn-block" >
		        	<span class="glyphicon glyphicon-plus"></span>
		        </button>
		 	</div>
		</div>
	</form>


	<?php 
		MostraTabela();
		if($_SESSION['qtdeitens']==0){
			echo '<button disabled="" id="singlebutton" type=button onclick="resolver()" class="btn btn-primary">Resolver</button>';
		}else{
			echo '<button id="singlebutton" type=button onclick="resolver()" class="btn btn-primary">Resolver</button>';
		}

	?>
 	
</div><!--<div class="container">-->
<br><br><br><br><br><br>

<script type="text/javascript">
function validar(capacidade){
	if((document.formulario.valor.value<=0)||(document.formulario.peso.value<=0)||(document.formulario.peso.value>capacidade)) {
	 	alert( "Preencha os campos corretamente!" );
	 	return false; 
    } 
}
function resolver(){
	window.location.href="solucao.php";
}
</script>


<?php require('/elements/footer.php' ); ?>