<?php 
session_start();
require '/functions/functions.php';
$capacidade=$_GET['capacidade'];
$_SESSION['capacidade']=$capacidade;
$_SESSION['qtdecolunas']=$capacidade+3;
$_SESSION['qtdelinhas']=1;
$_SESSION['qtdeitens']=0;
$_SESSION['itenslevados'] = '';
$_SESSION['colunainicial']=$_SESSION['qtdecolunas'];
$tabela =array();

$linha=0;
for ($coluna=0; $coluna <= $_SESSION['qtdecolunas']; $coluna++) 
{ 
	switch ($coluna) {
		case 0 :
			$tabela[$linha][$coluna]='Item';
			break;
		case 1 :
			$tabela[$linha][$coluna]='Valor';
			break;	
		case 2 :
			$tabela[$linha][$coluna]='Peso';
			break;	
		default:
			$tabela[$linha][$coluna]=$coluna-3;
			break;
	}
}


for ($coluna=0; $coluna <= $_SESSION['qtdecolunas']; $coluna++) 
{ 
	if ($coluna==0){
		$tabela[1][0]=$_SESSION['qtdeitens'];
	}else{
		$tabela[1][$coluna]=0;
	}
}
$_SESSION['tabela']=$tabela;
VerificaItens();
header('location:passo2.php');