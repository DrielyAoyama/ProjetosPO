<?php
session_start();
$tabela = array();
$tabela = $_SESSION['tabela'];
$_SESSION['qtdelinhas']=$_SESSION['qtdelinhas']+1;
$_SESSION['qtdeitens']=$_SESSION['qtdeitens']+1;


for ($coluna=0; $coluna <= $_SESSION['qtdecolunas'] ; $coluna++) { 
		switch ($coluna) 
		{
			case 0 :
				$tabela[$_SESSION['qtdelinhas']][$coluna]=$_SESSION['qtdeitens'];
				break;
			case 1 :
				$tabela[$_SESSION['qtdelinhas']][$coluna]=$_GET['valor'];
				break;
			case 2 :
				$tabela[$_SESSION['qtdelinhas']][$coluna]=$_GET['peso'];
				break;		
			default:
			    if($tabela[0][$coluna]==$_GET['peso'])
			    {
			    	$tabela[$_SESSION['qtdelinhas']][$coluna]=$_GET['valor'];
			    }else
			    {
			    	if($tabela[0][$coluna]>$_GET['peso']){
			    		$tabela[$_SESSION['qtdelinhas']][$coluna]=$_GET['valor']+$tabela[$_SESSION['qtdelinhas']-1][$coluna-($_GET['peso'])];
			    	}else{
			    		$tabela[$_SESSION['qtdelinhas']][$coluna]=$tabela[$_SESSION['qtdelinhas']-1][$coluna];
			    	}
			    }				
				break;
		}
		$item++;
}
$_SESSION['tabela']=$tabela;

header('location:passo2.php');