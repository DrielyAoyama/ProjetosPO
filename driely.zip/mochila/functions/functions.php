<?php

function MostraTabela()
{
    $tabela = array();
    $tabela=$_SESSION['tabela'];
    $conteudo = '';
    $conteudo=$conteudo.'<table class="table table-striped">
		                     <thead><tr>';
    for ($c=0; $c <= $_SESSION['qtdecolunas'] ; $c++) 
    { 
			$conteudo=$conteudo.'<th>'.$tabela[0][$c].'</th>';
	}
	$conteudo=$conteudo.'</tr></thead>';
	$conteudo=$conteudo.'<tbody>';
	for ($l=1; $l <= $_SESSION['qtdelinhas'] ; $l++) {
		$conteudo=$conteudo.'<tr>'; 
		for ($c=0; $c <= $_SESSION['qtdecolunas']; $c++) { 
			if ($c==0){
				$conteudo=$conteudo.'<td><strong>'.$tabela[$l][$c].'</strong></td>';
			}else{
				$conteudo=$conteudo.'<td>'.$tabela[$l][$c].'</td>';
			}
		}
		$conteudo=$conteudo.'</tr>';			
	}
	$conteudo=$conteudo.'</tbody>';
	$conteudo=$conteudo.'</table>';
	echo $conteudo;
}//function MostraTabela()


function VerificaItens(){
	$qtde=0;
	$itens = array();
    $itens=$_SESSION['itenslevados'];
    $tabela = array();
    $tabela=$_SESSION['tabela'];
    $coluna=$_SESSION['qtdecolunas'];

    for ($linha=$_SESSION['qtdelinhas']; $linha > 0 ;$linha--) { 
    	//if ($linha!=0){
    		if( $tabela[$linha][$coluna] != $tabela[$linha-1][$coluna]    ){
    			$_SESSION['itenslevados'][$qtde]=$tabela[$linha][0];
	    		$qtde++;
	    		//muda a coluna

	    		$coluna=($tabela[0][$coluna] - $tabela[$linha-1][0])+3;
	    		//módulo, consciderando que 3 = a coluna numero 0
	    		if ($coluna<3){
	    			$coluna=(3-$coluna)+3;
	    		}
	    	}
    	//}    	
    }

}