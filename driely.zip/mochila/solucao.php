<?php 
$tabela = array();
require('/elements/header.php' );
require('/functions/functions.php');
?>
<br>
<br>
<div class="container">	


	<?php 
		MostraTabela();
		VerificaItens();
	?>

	<div class="col-md-12">
	    <h2>Solução do problema</h2>
	        <p>Os itens que devem ser levados são :</p>
	        <?php 
	        	for ($i=0; $i < count($_SESSION['itenslevados'])-1; $i++) { 
	        		echo '<strong>O Item número '.$_SESSION['itenslevados'][$i].' vai ser levado na mochila;</strong><br>';
	        	}	        	
	        ?>        
	     
	</div><!--<div class="col-md-12">-->
</div><!--<div class="container">-->
<br><br><br><br><br><br>

<script type="text/javascript">
function validar(capacidade){
	if((document.formulario.valor.value<=0)||(document.formulario.peso.value<=0)||(document.formulario.peso.value>capacidade)) {
	 	alert( "Preencha os campos corretamente!" );
	 	return false; 
    } 
}
</script>


<?php require('/elements/footer.php' ); ?>